typedef struct {
       const char *name;
       const void *cmd;
} Sp;

static void removescratch(const Arg *arg);
static void setscratch(const Arg *arg);
static void togglescratch(const Arg *arg);

